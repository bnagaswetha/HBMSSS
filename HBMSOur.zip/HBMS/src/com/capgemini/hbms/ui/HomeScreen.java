package com.capgemini.hbms.ui;

import java.util.Scanner;

public class HomeScreen {
	public static Scanner sc=new Scanner(System.in);
	static UserScreen userScreen=new UserScreen();
	static AdminScreen adminScreen=new AdminScreen();


	public static void main(String[] args) {

		
		System.out.println("\t\t\t***Welcome To Hotel Booking Management Application***");
		while(true){
			System.out.println("1.SIGN UP\n2.LOGIN");
			int choice=sc.nextInt();
			switch(choice){
			case 1:  
				System.out.println("\t\t\t\t User Screen");
				userScreen.registerUser();
			break;

			case 2:    System.out.println("1.Admin\n 2.User/HotelEmployee");
			int choice1=sc.nextInt();
			switch(choice1){
			case 2:
				System.out.println("Enter your email");
				String email=sc.next();
				System.out.println("Enter your password");
				String password=sc.next();


				if(userScreen.checkValidUser(email,password)){
					while(true){
						System.out.println("1.Search Hotels");
						System.out.println("2.Book Hotels");
						System.out.println("3.View Booking Status");
						System.out.println("4.Exit");
						int choice2=sc.nextInt();
						switch(choice2){
						case 1:
							adminScreen.displayHotelDetails();
							break;

						case 2:
							//adminScreen.displayHotelDetails();
							System.out.println("Booking Id:"+userScreen.addBookingDetails());
							break;

						case 3:
							userScreen.getBookingDetails(email);
							break;
						case 4:
							System.out.println("Thank you");
							System.exit(0);
							break;
						}

					}
				}
				break;
			case 1:
				if(adminScreen.checkValidAdmin()){
					while(true){
						System.out.println("1.Add Hotels");
						System.out.println("2.Delete Hotel");
						System.out.println("3.View List of  Hotels");
						System.out.println("4.Add Room");
						System.out.println("5.Delete Room");
						System.out.println("6.View Booking Details of specific hotel");
						System.out.println("7.View Booking Details for specific date");
						System.out.println("8.Exit");

						int ch=sc.nextInt();
						switch(ch){
						case 1:if(adminScreen.addHotelDetails())
							System.out.println("succece");
						break;
						case 2:adminScreen.deleteHotelDetails();
						break;
						case 3:adminScreen.displayHotelDetails();
						break;
						case 4:adminScreen.addRoom();
						break;
						case 5:adminScreen.deleteRoom();;
						break;
						case 6:

							adminScreen.getBookingDetails();
							break;
						case 7:

							adminScreen.getBookingDetailsDate();
							break;
						case 8:System.exit(0);
								break;
						}
					}
				}else{
					System.out.println("In Valid");

				}
				break;

			}


			break;
			case 3:
				System.exit(0);
				break;
			}
			
		}




	}
}
