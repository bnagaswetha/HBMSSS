package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.dao.IRoomDao;
import com.capgemini.hbms.dao.RoomDaoImpl;
import com.capgemini.hbms.exception.HBMSException;

public class RoomServiceImpl implements IRoomService{
	IRoomDao dao = new RoomDaoImpl();
	IHotelDao daoh=new HotelDaoImpl();
	@Override
	public Boolean addRoomDetails(Room room) throws HBMSException {
		if(hotelExists(room.getHotelId()))
			return  dao.addRoomDetails(room);
		return false;
	}

	private boolean hotelExists(Integer hotelId) throws HBMSException {
		
		return daoh.hotelExist(hotelId);
	}

	@Override
	public void deleteRoomDetails(Integer hotelId1, String roomNo1)
			throws HBMSException {
		dao.deleteRoomDetails(hotelId1, roomNo1);
		
	}

	@Override
	public List<Room> displayRoomDetails() throws HBMSException {
		// TODO Auto-generated method stub
		return dao.displayRoomDetails();
	}

	@Override
	public List<Room> displayRoomDetails(int hotel_id) throws HBMSException {
		return dao.displayRoomDetails(hotel_id);
		 
	}

	@Override
	public void updateRoomPrice(int room_id, Double price) throws HBMSException {
		dao.updateRoomPrice(room_id,price);
		
	}

	@Override
	public void updateType(int roomid, String type) throws HBMSException {
		dao.updateType(roomid,type);
		
	}

}
