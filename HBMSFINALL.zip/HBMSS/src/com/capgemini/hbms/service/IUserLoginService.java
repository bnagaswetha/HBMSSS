package com.capgemini.hbms.service;


import com.capgemini.hbms.exception.HBMSException;

public interface IUserLoginService {
	
	public boolean checkValidUser(String email,String password) throws HBMSException;
	public boolean checkValidAdmin(String email,String password) throws HBMSException;
	public Integer getUserId(String email) throws HBMSException;

}
