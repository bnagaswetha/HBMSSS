package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;


public class UserLoginImpl implements IUserLogin{



	@Override
	public boolean checkValidUser(String email, String password)
			throws HBMSException {

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.CHECK_VALID_USER);


				){

			preparedStatement.setString(1,email);
			preparedStatement.setString(2,password);



			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				return true;
			}else
			{
				return false;
			}




		}catch(SQLException e){

			throw new HBMSException("Technical error refer log");
		}
	}

	@Override
	public boolean checkValidAdmin(String email, String password)
			throws HBMSException {

		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.CHECK_VALID_USER);


				){

			preparedStatement.setString(1,email);
			preparedStatement.setString(2,password);



			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				if(rs.getString("role").equals("admin"))
					return true;
			}else
			{
				return false;
			}




		}catch(SQLException e){

			throw new HBMSException("Technical error refer log");
		}
		return false;
	}

	@Override
	public Integer getUserId(String email) throws HBMSException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.GET_USER_ID);


				){

			preparedStatement.setString(1,email);

			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}else
			{
				return null;
			}

		}catch(SQLException e){

			throw new HBMSException("Technical error refer log");
		}

	}

}
