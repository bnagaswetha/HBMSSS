package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class HotelDaoImpl implements IHotelDao {
	List<Hotel> hotelList =new ArrayList<>();

	@Override
	public Boolean addHotelDetails(Hotel hotel) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_HOTEL_DETAILS);
										){
			
			preparestatement.setInt(1,hotel.getHotelId());
			preparestatement.setString(2, hotel.getCity());
			preparestatement.setString(3, hotel.getHotelName());
			preparestatement.setString(4, hotel.getAddress());
			preparestatement.setString(5, hotel.getDescription());
			preparestatement.setDouble(6, hotel.getAvgRatePerNight());
			preparestatement.setString(7, hotel.getPhoneNo1());
			preparestatement.setString(8, hotel.getPhoneNo2());
			preparestatement.setString(9, hotel.getRating());
			preparestatement.setString(10, hotel.getEmail());
			preparestatement.setString(11, hotel.getFax());
			
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteHotelDetails(Integer hotelId1) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.DELETE_HOTEL);)
										{
			preparestatement.setInt(1, hotelId1);;

			int i=preparestatement.executeUpdate();
			if(i>0){
				System.out.println("deleted");
			}else{
				System.out.println("Not deleted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public List<Hotel> displayHotelDetails() throws HBMSException {
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			
			ResultSet resultSet=statement.executeQuery(QueryMapper.DISPLAY_HOTELDETAILS);
			while(resultSet.next()){
				Hotel hotel=new Hotel();
				populateHotel(hotel,resultSet);
				hotelList.add(hotel);
				
				
			}
			return hotelList;
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hotelList;
	}

	private void populateHotel(Hotel hotel, ResultSet resultSet) throws SQLException {
		hotel.setHotelId(resultSet.getInt("hotel_id"));
		hotel.setCity(resultSet.getString("city"));
		hotel.setHotelName(resultSet.getString("hotel_name"));
		hotel.setAddress(resultSet.getString("address"));
		hotel.setDescription(resultSet.getString("description"));
		hotel.setAvgRatePerNight(resultSet.getDouble("avg_rate_per_night"));
		hotel.setPhoneNo1(resultSet.getString("phone_no1"));
		hotel.setPhoneNo2(resultSet.getString("phone_no2"));
		hotel.setRating(resultSet.getString("rating"));
		hotel.setEmail(resultSet.getString("email"));
		hotel.setFax(resultSet.getString("fax"));
		
		
	}

	@Override
	public void updatePrice(Double price, Integer hotelId2) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.UPDATE_HOTEL_price);){
			
			preparestatement.setDouble(1, price);
			preparestatement.setInt(2, hotelId2);
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				System.out.println("Updated");
			}else{
				System.out.println("Fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateDescrption(String string, Integer hotelId2)
			throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.UPDATE_HOTEL_description);){
			
			preparestatement.setString(1, string);
			preparestatement.setInt(2, hotelId2);
			
			int i=preparestatement.executeUpdate();
			if(i>0){
				System.out.println("Updated");
			}else{
				System.out.println("Fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
