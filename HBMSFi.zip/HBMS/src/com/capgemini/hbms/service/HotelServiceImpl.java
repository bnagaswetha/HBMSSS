package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.dao.HotelDaoImpl;
import com.capgemini.hbms.dao.IHotelDao;
import com.capgemini.hbms.exception.HBMSException;

public class HotelServiceImpl implements IHotelService{
	IHotelDao dao = new HotelDaoImpl();
	


	@Override
	public Boolean addHotelDetails(Hotel hotel) throws HBMSException {
		// TODO Auto-generated method stub
		return dao.addHotelDetails(hotel);
	}



	@Override
	public void deleteHotelDetails(Integer hotelId1) throws HBMSException {
		dao.deleteHotelDetails(hotelId1);
		
	}



	@Override
	public List<Hotel> displayHotelDetails() throws  HBMSException {
		return dao.displayHotelDetails();
	}



	@Override
	public void updatePrice(Double price, Integer hotelId2) throws HBMSException {
		dao.updatePrice(price,hotelId2);
		
	}



	@Override
	public void updateDescrption(String string, Integer hotelId2) throws HBMSException {
		dao.updateDescrption(string,hotelId2);
		
	}
	

}
