package com.capgemini.hbms.ui;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserLoginService;
import com.capgemini.hbms.service.IUserRegistrationService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserLoginServiceImpl;
import com.capgemini.hbms.service.UserRegistrationService;


public class UserScreen {
	public static IUserLoginService userService=new UserLoginServiceImpl();
	static AdminScreen adminScreen=new AdminScreen();
	public static IUserRegistrationService userReg=new UserRegistrationService();
	public static IBookingService bookingService=new BookingServiceImpl();
	public static Scanner sc=new Scanner(System.in);
	public static IHotelService hotelService=new HotelServiceImpl();
	static IRoomService roomService = new RoomServiceImpl();
	List<Hotel> hotelList =new ArrayList<>();
	public static Validator validator=new Validator();

	public  boolean checkValidUser(String email, String password) {

		try {
			if(userService.checkValidUser(email, password)){
				//System.out.println("you are valid user ");
				return true;
			}
			else{
				//System.out.println("you are invalid user");
				return false;
			}
		} catch (HBMSException e) {

			e.printStackTrace();
		}

		return false;
	}

	public boolean registerUser()  {

		System.out.println("Enter your name");
		String user_name=sc.next();
		if(validator.isValidUserName(user_name)){
			System.out.println("Enter your role: User/Employee");
			String role=sc.next();
			if(validator.isValidRole(role)){
				System.out.println("Enter your mobile number");
				String mobile_no=sc.next();
				if(validator.isValidMobileNo(mobile_no)){
					System.out.println("Enter your phone");
					String phone=sc.next();
					if(validator.isValidPhoneNo(phone)){
						System.out.println("Enter your address");
						String address=sc.next();
						System.out.println("Enter your password");
						String password=sc.next();
						if(validator.isValidPassword(password)){
							System.out.println("Enter your email");
							String email=sc.next();
							if(validator.isValidEmail(email)){
								Users user=new Users();
								user.setAddress(address);
								user.setEmail(email);
								user.setMobile_no(mobile_no);
								user.setPassword(password);
								user.setPhone(phone);
								user.setRole(role);
								user.setUser_name(user_name);
								try {
									if(userReg.registerUser(user))
									{
										System.out.println("Registration Completed successfully");
									}
									else{
										System.out.println("Unable to register");
									}
								} catch (HBMSException e1) {

									e1.printStackTrace();
								}
							}else{
								System.out.println("Enter Valid Email");
							}
						}else{
							System.out.println("Enter Valid Password");
						}

					}else{
						System.out.println("Enter Valid Phone");
					}
				}else{
					System.out.println("Enter Valid Mobile Number");
				}

			}else{
				System.out.println("Enter Valid Role");
			}

		}else{
			System.out.println("Enter Valid Username");
		}
		return false;



	}
	public Integer addBookingDetails(){
		try {
			//adminScreen.displayHotelDetails();
			System.out.println("Enter hotel id in which you want to book room");
			int hotel_id=sc.nextInt();
			List<Room> roomList=new ArrayList<>();
			roomList=roomService.displayRoomDetails(hotel_id);
			showRoomdetails(roomList);
			System.out.println("Enter room_id");
			Integer roomId=sc.nextInt();
			System.out.println("Enter your mail Id");
			String email=sc.next();
			Integer userId=userService.getUserId(email);
			System.out.println("Enter Check-in date");
			String fromDate=sc.next();
			LocalDate fdate=LocalDate.parse(fromDate);

			System.out.println("Enter Check-out date");
			String outDate=sc.next();
			LocalDate odate=LocalDate.parse(outDate);

			System.out.println("Number of Adults");
			Integer adults=sc.nextInt();
			System.out.println("Number of Childrens");
			Integer childs=sc.nextInt();


			BookingDetails bookingDetails=new BookingDetails();
			bookingDetails.setUser_id(userId);
			bookingDetails.setRoom_id(roomId);
			bookingDetails.setBooked_from(fdate);
			bookingDetails.setBooked_to(odate);
			bookingDetails.setNo_of_adults(adults);
			bookingDetails.setNo_of_children(childs);
			return bookingService.addBookingDetails(bookingDetails);

		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;



	}

	private void showRoomdetails(List<Room> roomList) {
		for(Room room:roomList){
			System.out.println(room);
		}

	}

	public void getBookingDetails(String email) {
		try {
			BookingDetails bookingDetails=bookingService.getBookingDetails(email);
			System.out.println(bookingDetails);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
