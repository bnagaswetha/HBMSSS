package com.capgemini.hbms.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.hbms.exception.HBMSException;

public class UserLoginImplTest {
	static UserLoginImpl userLogin=new UserLoginImpl();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCheckValidUser() {
		try {
			assertTrue(userLogin.checkValidUser("ak@gmail.com","akhilak"));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testCheckValidAdmin() {
		try {
			assertTrue(userLogin.checkValidAdmin("swetha@gmail.com","swetha"));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
